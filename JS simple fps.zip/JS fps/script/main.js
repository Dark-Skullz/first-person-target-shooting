"use strict";

let canvas, canvasContext;
let FPS;
let playerX, playerY, playerSpeedX = 0, playerSpeedY = 0;
let interval;
let aimPointX, aimbointY;
let gunX = 0, gunY = 300;
let randomInt;
let randomInt2;
let score;
let gameLoop
let countDown, countDownSeconds;

window.onload = function() {
    startGame();
};

document.addEventListener('keydown', function(event) {
    if(event.keyCode == 32) {
		shoot();
    }
    else if(event.keyCode == 65) {
		if(playerX >= -50) {
			playerSpeedX = 0;
		}
		else {
			playerSpeedX = 5;
		}
    } 
	else if(event.keyCode == 87) {
		if(playerY >= -50) {
			playerSpeedY = 0;
		}
		else {
			playerSpeedY = 5;
		}
    } 
	else if(event.keyCode == 83) {
		if(playerY + 1200 <= 800) {
			playerSpeedY = 0;
		}
		else {
			playerSpeedY = -5;
		}
    } 
	else if(event.keyCode == 68) {
		if (playerX + 1500 <= 800 ) {
			playerSpeedX = 0;
		}
		else {
			playerSpeedX = -5;
		}
    }
});

document.addEventListener('keyup', function(event) {
	playerSpeedX = 0;
	playerSpeedY = 0;
});

function shoot() {
	aimPointX = gunX + 389;
	aimbointY = gunY + 10;
	
	if(aimPointX > playerX + randomInt && aimPointX < playerX + randomInt + 80 && aimbointY > playerY + randomInt2 && aimbointY < playerY + randomInt2 + 80 ) {
		getRandomInt(400, 800);
		getRandomInt2(500, 600);
		console.log("well done!");
		score +=1;
	}
	else {
		console.log("you missed");
	}
}

function startGame() {
	canvas = document.getElementById("gameCanvas");
	canvasContext = canvas.getContext("2d");
	
	
	resetPlayer();
	
	shoot();
	
	score = 0;
	
	getRandomInt(400, 800);
	getRandomInt2(500, 600);
	
	window.setTimeout(stopGameLoop, 1000*60);
	
	FPS = 60;
	gameLoop = setInterval( function() {
		moveEverything();
		drawEverything();
	}, 1000/FPS);
	
	countDownSeconds = 60;
	countDown = setInterval( function() {
		if(countDownSeconds > 0) {
			countDownSeconds = countDownSeconds - 1;
		}
		else {
			stopCountDown();
			stopGameLoop();
			alert("Well done, you hit the target " + score + " times!!!")
		}
	}, 1000);
	
	
}

function resetPlayer() {
	playerX = -300;
	playerY = -400;
}

function moveEverything() {
	playerX = playerX + playerSpeedX;
	playerY = playerY + playerSpeedY;
}

function drawEverything() {
	
	var background = new Image();
    background.src = "images/bg.png";
	
	var gun = new Image();
    gun.src = "images/gun.png";
	
	var target = new Image();
    target.src = "images/target.png";
	
	//draws background
    canvasContext.drawImage(background, playerX, playerY);   

	//test rect
	canvasContext.drawImage(target, playerX + randomInt, playerY + randomInt2);


	//draws guns
	canvasContext.drawImage(gun, gunX, gunY); 
	
	//shows the score
	canvasContext.font = "bold 20px Helvetica, Arial, sans-serif";
	canvasContext.fillStyle = "steelblue";
	canvasContext.fillText("score: " + score, (canvas.width/8), 50);
	canvasContext.fillText( countDownSeconds + " seconds left", (canvas.width/8) * 5, 50);
	
}

function stopGameLoop() {
  clearInterval(gameLoop);
  console.log("game freezed.");
}

function stopCountDown() {
  clearInterval(countDown);
  console.log("countdown stopped");
}

function getRandomInt(min, max) {
	min = Math.ceil(min) + 1;
	max = Math.floor(max);
	randomInt = Math.floor(Math.random() * (max - min) + min);
}

function getRandomInt2(min, max) {
	min = Math.ceil(min) + 1;
	max = Math.floor(max);
	randomInt2 = Math.floor(Math.random() * (max - min) + min);
}

function colorRect(leftX, topY, width, height, drawColor) {
	canvasContext.fillStyle = drawColor;
	canvasContext.fillRect(leftX, topY, width, height);
}

function colorCircle(centerX, centerY, radius, drawColor) {
	canvasContext.fillStyle = drawColor;
    canvasContext.beginPath();
    canvasContext.arc(centerX,centerY,radius,0,Math.PI*2,true);
    canvasContext.closePath();
    canvasContext.fill();
}